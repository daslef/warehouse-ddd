class OutOfStock(Exception):
    """
    OrderLine cannot be allocated
    """

    pass
