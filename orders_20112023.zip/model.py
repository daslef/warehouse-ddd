from datetime import date
from typing import Optional, Self


class OrderLine:
    """Товарная позиция"""

    def __init__(self, orderid: str, sku: str, qty: int) -> None:
        self.orderid = orderid
        self.sku = sku
        self.qty = qty

    def __hash__(self):
        return hash((self.orderid, self.sku, self.qty))

    def __eq__(self, other_order_line) -> bool:
        return hash(self) == hash(other_order_line)


class Batch:
    """Партия"""

    def __init__(self, reference: str, sku: str, qty: int, eta: Optional[date] = None):
        self.reference = reference
        self.sku = sku
        self.initial_quantity = qty
        self.eta = eta
        self.allocations = set()

    def __eq__(self, other_batch) -> bool:
        return self.reference == other_batch.reference

    def __hash__(self) -> int:
        return hash(self.reference)

    def __gt__(self, other_batch: Self) -> bool:
        if self.eta is None:
            return False
        if other_batch.eta is None:
            return True
        return self.eta > other_batch.eta

    @property
    def allocated_quantity(self):
        return sum(line.qty for line in self.allocations)

    @property
    def available_quantity(self):
        return self.initial_quantity - self.allocated_quantity

    def allocate(self, line: OrderLine) -> None:
        self.allocations.add(line)

    def deallocate(self, line: OrderLine) -> None:
        if line in self.allocations:
            self.allocations.remove(line)

    def can_allocate(self, line: OrderLine) -> bool:
        if line in self.allocations:
            return False
        if self.sku != line.sku:
            return False
        return self.available_quantity >= line.qty
